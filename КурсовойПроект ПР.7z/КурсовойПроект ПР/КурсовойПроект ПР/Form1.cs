﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;

namespace КурсовойПроект_ПР
{
    public partial class Form1 : Form
    {
        
        string[] logpass = new string[2];
        List<string[]> list = new List<string[]>();
        bool link = false;
        bool checker = false;
        class Person
        {
            private string login;
            private string pass;

            public Person(string login, string pass)
            {
                this.login = login;
                this.pass = pass; 
            }
        }
        public Form1()
        {
            InitializeComponent();

           

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checker == false)
            {
                checker = true;
            }
            else
            {
                checker = false;
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            GraphicsPath buttonPath = new GraphicsPath();
            Rectangle newRectangle = pictureBox1.ClientRectangle;
            newRectangle.Inflate(10, 11);
            e.Graphics.DrawEllipse(Pens.Transparent, newRectangle);
            buttonPath.AddEllipse(newRectangle);
            pictureBox1.Region = new Region(buttonPath);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void CloseForm1(object sender, FormClosingEventArgs e)
        {
            e.Cancel = false;
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            bool errpass = false;
            bool errlog = false;
            if(link == false)
            {
            foreach (string[] logpass in list)
            {
                if (textBox1.Text == logpass[0] && textBox2.Text == logpass[1])
                {
                Приложение p = new Приложение();
                p.Show();
                        this.Close();
                        if (checker == true)
                        {
                            StreamWriter sr = new("C:/Users/makcp/Downloads/Telegram Desktop/КурсовойПроект ПР/КурсовойПроект ПР/auth.txt");
                            sr.WriteLine($"{logpass[0]}:{logpass[1]}");
                            sr.Close();
                        }
                        errpass = false;
                        errlog = false;
                        break;
                }
                else if(textBox1.Text == logpass[0])
                    {
                        errlog = false;
                        errpass = true;
                    }
                else if(textBox2.Text == logpass[1])
                    {
                        errpass = true;
                        errlog = true;
                    }
                else
                    {
                        errpass = true;
                        errlog = true;
                    }
                if (errlog == true)
                    {
                        pictureBox4.Visible = true;
                        toolTip1.SetToolTip(pictureBox4, "Неверный логин");
                    }
                    else
                    {
                        pictureBox4.Visible = false;
                    }
                if (errpass == true)
                    {
                        pictureBox5.Visible = true;
                        toolTip1.SetToolTip(pictureBox5, "Неверный пароль");
                    }
                    else
                    {
                        pictureBox5.Visible = false;
                    }
                
            }
            }
            else
            {
                ///StreamWriter streamWriter = new StreamWriter("C:/Users/makcp/source/repos/КурсовойПроект ПР/КурсовойПроект ПР/input.txt", true);
                StreamReader sr = new StreamReader("C:/Users/makcp/Downloads/Telegram Desktop/КурсовойПроект ПР/КурсовойПроект ПР/TextFile1.txt");
                if (textBox1.Text != "" && textBox2.Text != "")
                {
                    pictureBox4.Visible = false;
                    pictureBox5.Visible = false;
                    pictureBox6.Visible = false;
                    if (textBox2.Text.Length < 6)
                    {
                        pictureBox5.Visible = true;
                        toolTip1.SetToolTip(pictureBox5,"Длина пароля меньше 6-ти символов");
                        sr.Close();
                    }
                    if (textBox2.Text.Length > 20)
                    {
                        pictureBox5.Visible = true;
                        toolTip1.SetToolTip(pictureBox5, "Длина пароля больше 20-ти символов");
                        sr.Close();
                    }
                    if (textBox2.Text.Contains(":"))
                    {
                        pictureBox5.Visible = true;
                        toolTip1.SetToolTip(pictureBox5, "В пароле не должно содержаться двоеточий (:)");
                        sr.Close();
                    }
                    if (textBox1.Text.Contains(":"))
                    {
                        pictureBox4.Visible = true;
                        toolTip1.SetToolTip(pictureBox4, "В Логине не должно содержаться двоеточий (:)");
                        sr.Close();
                    }
                    if (textBox1.Text.Length > 20)
                    {
                        pictureBox4.Visible = true;
                        toolTip1.SetToolTip(pictureBox4, "Длина логина больше 20-ти символов");
                        sr.Close();
                    }
                    if (textBox3.Text != sr.ReadToEnd())
                    {
                        pictureBox6.Visible = true;
                        toolTip1.SetToolTip(pictureBox6, "Проверочный код введён неправильно");
                        sr.Close();
                    }
                    foreach (string[] auth in list)
                    {
                        if (textBox1.Text == auth[0])
                        {
                            pictureBox4.Visible = true;
                            toolTip1.SetToolTip(pictureBox4, "Такой логин уже зарегистрирован в системе");
                            sr.Close();
                            break;
                        }
                    }
                    if(pictureBox4.Visible==false && pictureBox5.Visible == false && pictureBox6.Visible == false)
                    {
                        StreamWriter streamWriter = new StreamWriter("c:/users/makcp/downloads/telegram desktop/курсовойпроект пр/КурсовойПроект ПР/input.txt", true);
                        sr.Close();
                        streamWriter.WriteLine($"{textBox1.Text}:{textBox2.Text}");
                        streamWriter.Close();
                    }
                }
            }
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamReader sr = new ("c:/users/makcp/downloads/telegram desktop/курсовойпроект пр/КурсовойПроект ПР/input.txt");
            StreamReader sr1 = new("C:/Users/makcp/Downloads/Telegram Desktop/КурсовойПроект ПР/КурсовойПроект ПР/auth.txt");
            string ss = sr1.ReadLine();
            if (ss == null)
            {
                string s = "";
                sr.ReadLine();
                while ((s = sr.ReadLine()) != null)
                {
                    logpass = s.Split(":");
                    list.Add(logpass);
                }
                sr.Close();
            }
            else
            {
                logpass = ss.Split(":");
                Приложение p = new Приложение();
                p.Show();
                this.Close();
                
            }
            sr1.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (link == false) {
                checkBox1.Visible = false;
                Control control = new Control();
                textBox3.Location = new Point(100, 271);
                textBox3.Visible = true;
                
                linkLabel1.Text = "Авторизация";
                link = true;
                pictureBox4.Visible = false;
                pictureBox5.Visible = false;
                pictureBox6.Visible = false;
            }
            else
            {
                checkBox1.Visible = true;
                textBox3.Visible = false;
                
                linkLabel1.Text = "Регистрация";
                link = false;
                pictureBox4.Visible = false;
                pictureBox5.Visible = false;
                pictureBox6.Visible = false;
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Admin admin = new();
            admin.Show();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }
    }
}
