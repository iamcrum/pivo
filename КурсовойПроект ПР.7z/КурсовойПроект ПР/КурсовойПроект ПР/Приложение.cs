﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;

namespace КурсовойПроект_ПР
{
    public partial class Приложение : Form
    {
        const int SC_CLOSE = 0xF010;
        const int MF_BYCOMMAND = 0;
        const int WM_NCLBUTTONDOWN = 0x00A1;
        const int WM_NCHITTEST = 0x0084;
        const int HTCAPTION = 2;
        [DllImport("User32.dll")]
        static extern int SendMessage(IntPtr hWnd,
        int Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("User32.dll")]
        static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("User32.dll")]
        static extern bool RemoveMenu(IntPtr hMenu, int uPosition, int uFlags);

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_NCLBUTTONDOWN)
            {
                int result = SendMessage(m.HWnd, WM_NCHITTEST,
                IntPtr.Zero, m.LParam);
                if (result == HTCAPTION)
                    return;
            }
            base.WndProc(ref m);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            IntPtr hMenu = GetSystemMenu(Handle, false);
            RemoveMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);
        }
        bool session = true;
        public Приложение()
        {
            InitializeComponent();
        }

        private void Приложение_Load(object sender, EventArgs e)
        {
            
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            StreamWriter sr = new ("C:/Users/makcp/Downloads/Telegram Desktop" +
                "/КурсовойПроект ПР/КурсовойПроект ПР/auth.txt",false);
            sr.Close();
            session = false;
            Form1 auth = new();
            auth.Show();
            this.Close();

        }
        
        private void Приложение_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (session == true)
            {
                Environment.Exit(1);
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void профильToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void работаСКлиентомToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Admin newf = new();
            newf.Show();
            newf.textBox1.Text = "Введите номер банковской карты клиента";
        }
    }
}
