﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace КурсовойПроект_ПР
{
    public partial class HelloWorld : Form
    {
        public HelloWorld()
        {
            InitializeComponent();
        }

        async private void HelloWorld_Load(object sender, EventArgs e)
        {
            this.Opacity = 0.05;
            for (int i = 0; i < 100000; i++)
            {
                await Task.Delay(50);
                this.Opacity += 0.05;
                if (this.Opacity == 1)
                {
                    break;
                }
            }
            for (int i = 0; i < 10000; i++)
            {
                await Task.Delay(50);
                this.Opacity -= 0.05;
                if (this.Opacity == 0)
                {
                    await Task.Delay(500);
                    this.Hide();
                    break;
                }
            }
            Form1 auth = new();
            Program.f1 = auth;
            auth.Show();
        }
    }
}
