﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace КурсовойПроект_ПР
{
    public partial class Работа : Form
    {
        List<string[]> list = new List<string[]>();
        bool editkey = false;
        public string cardNumber;
        public string name;
        public string balance;
        public bool debt;
        public string debtsum;
        public Работа()
        {
            InitializeComponent();
            textBox1.Text = name;
            textBox2.Text = cardNumber;
            textBox3.Text = balance;
            if (debt == true)
            {
                textBox4.Text = debtsum;
            }
            else
            {
                textBox4.Text = "Отсутствует";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (editkey == false)
            {
                editkey = true;
                textBox1.ReadOnly = false;
                textBox2.ReadOnly = false;
                textBox3.ReadOnly = false;
                textBox4.ReadOnly = false;
            }
            else
            {
                editkey = false;
                textBox1.ReadOnly = true;
                textBox2.ReadOnly = true;
                textBox3.ReadOnly = true;
                textBox4.ReadOnly = true;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (debt == true)
            {
                foreach (string[] item in Admin.list)
                {
                    if (item[0] == cardNumber)
                    {
                        Admin.list.Remove(item);   
                    }
                }
                StreamWriter sw = new("C:/Users/makcp/Downloads/Telegram Desktop/КурсовойПроект ПР/КурсовойПро" +
                    "ект ПР/TextFile2.txt", false);
                foreach (string[] item in Admin.list)
                {
                    if (item[3]=="false")
                    {
                        sw.WriteLine($"{item[0]}:{item[1]}:{item[2]}:{item[3]}");
                    }
                    else
                    {
                        sw.WriteLine($"{item[0]}:{item[1]}:{item[2]}:{item[3]}:{item[4]}");
                    }
                    
                }
            }
            else
            {
                MessageBox.Show("У клиента имеется задолженность");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (string[] item in Admin.list)
            {
                if (item[0] == cardNumber)
                {
                    item[1] = name;
                    item[2] = balance;
                    item[3] = 
                }
            }
            StreamWriter sw = new("C:/Users/makcp/Downloads/Telegram Desktop/КурсовойПроект ПР/КурсовойПро" +
                   "ект ПР/TextFile2.txt", false);
            foreach (string[] item in Admin.list)
            {
                if (item[3] == "false")
                {
                    sw.WriteLine($"{item[0]}:{item[1]}:{item[2]}:{item[3]}");
                }
                else
                {
                    sw.WriteLine($"{item[0]}:{item[1]}:{item[2]}:{item[3]}:{item[4]}");
                }

            }
        }
    }
}
