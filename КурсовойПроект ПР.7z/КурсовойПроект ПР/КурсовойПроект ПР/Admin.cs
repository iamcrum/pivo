﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace КурсовойПроект_ПР
{
    public partial class Admin : Form
    {
        string[] client = new string[5];
        public static List<string[]> list = new List<string[]>();
        public int x = 0;
        public bool key = true;
        public Admin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if ((textBox1.Text == "Imaginebear11")&&(key==true))
            {
                StreamWriter sw = new("C:/Users/makcp/Downloads/Telegram Desktop/КурсовойПроект ПР/КурсовойПро" +
                    "ект ПР/TextFile1.txt", true);
                Random rand = new();
                x = rand.Next(1000, 10000);
                this.Close();
                MessageBox.Show($"Новый пароль для регистрации: {x}");
                sw.Write(x);
                sw.Close();
            }
            if (key == false)
            {
                button1.Visible = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamReader sr = new("C:/Users/makcp/Downloads/Telegram Desktop/КурсовойПроект ПР/КурсовойПро" +
                    "ект ПР/TextFile2.txt");
            
                string s = "";
                sr.ReadLine();
                while ((s = sr.ReadLine()) != null)
                {
                    client = s.Split(":");
                    list.Add(client);
                if (client[3]=="false")
                {
                    client[4] = "0";
                }
                }
            sr.Close();
            foreach (string[] item in list)
            {
                if (item[0] == textBox1.Text)
                {
                    Работа work = new();
                    work.Show();

                    work.cardNumber = item[0];
                    work.name = item[1];
                    work.balance = item[2];
                    work.debt = Convert.ToBoolean(item[3]);
                    work.debtsum = item[4];
                }
            }
        }
    }
}
